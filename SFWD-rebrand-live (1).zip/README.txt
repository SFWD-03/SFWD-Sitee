SOUTH FLORIDA WINDOWS & DOORS — REBRAND (black + chrome)
Ready to replace the live site at myflwindows.com

WHAT'S IN THIS FOLDER
  index.html                  The full site (all pages), rebranded. Replaces the current index.html.
  sfwd-brand-logo.png         New chrome logo (homepage hero, footer, call-to-action strip)
  sfwd-brand-mark.png         Round emblem (browser tab icon, homepage background mark)
  pgt-*.webp (9 files)        PGT 2026 brochure covers for the Brochures page

All other images (job photos, before/after, team photo, etc.) are already on the
live server and are referenced by the same filenames, so they don't need re-uploading.

KEPT FROM THE LIVE SITE (unchanged)
  - CallRail number swapping script
  - Google Analytics (G-3JH3NW9N7R)
  - reCAPTCHA on forms, form handling, Google Maps embeds
  - Page title, meta description, Open Graph tags, canonical URL

HOW TO PUBLISH
  1. Download a backup of the current index.html from the server first.
  2. Upload everything in this folder to the site's root folder (same folder as the
     current index.html), replacing index.html.
  3. Clear the site/CDN cache, then open myflwindows.com in a private window.
  4. Spot-check: homepage logo, a form submission, the CallRail number on the page,
     About Us > Product Brochures, and the site on a phone.
  To roll back: re-upload the backup index.html.
